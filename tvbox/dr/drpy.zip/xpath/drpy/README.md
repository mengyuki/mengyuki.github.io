# CatVodSpiderJS

```
思维没有边界 一切皆有可能
```

## About

New version of catvod spider run with js engine.

Support in CatVod (CrossPlatform) version 6.0 or above.

- Android/Windows/Linux base on QuickJS.
- iOS base on JavaScriptCore.

This repository is just a simple demo. For complete development documents, refer to group files. 

加载链接: clan://localhost/drpy/cfg.json
